package handlers

import (
    "net/http"
)

// TestHandler comment goes here
func (h *Handlers) TestHandler(w http.ResponseWriter, r *http.Request) {

}
