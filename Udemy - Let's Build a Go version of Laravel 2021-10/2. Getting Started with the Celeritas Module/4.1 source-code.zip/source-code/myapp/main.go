package main

import "github.com/tsawler/celeritas"

type application struct {
	App *celeritas.Celeritas
}

func main() {
	initApplication()
}
