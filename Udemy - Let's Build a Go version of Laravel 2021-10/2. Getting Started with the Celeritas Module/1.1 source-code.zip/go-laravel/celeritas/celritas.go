package celeritas


func TestFunc(a, b int) int {
	return a + b
}
