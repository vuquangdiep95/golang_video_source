package main

import (
	"fmt"
	"github.com/tsawler/celeritas"
)

func main() {
	fmt.Println(celeritas.TestFunc(1, 1))
}