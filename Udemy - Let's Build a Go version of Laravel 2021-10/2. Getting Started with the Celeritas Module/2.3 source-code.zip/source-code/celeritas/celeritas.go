package celeritas

func TestFunc(a, b int) int {
	return a + b
}

func TestFunc2(a, b int) int {
	return a - b
}

func TestFunc3(a, b int) int {
	return a *b
}