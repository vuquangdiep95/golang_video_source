package celeritas

type initPaths struct {
	rootPath string
	folderNames []string
}