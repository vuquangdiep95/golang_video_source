package main

import "sync"

// The Dining Philosophers problem is well known in computer science circles.
// Five philosophers, numbered from 0 through 4, live in a house where the
// table is laid for them; each philosopher has their own place at the table.
// Their only difficulty – besides those of philosophy – is that the dish
// served is a very difficult kind of spaghetti which has to be eaten with
// two forks. There are two forks next to each plate, so that presents no
// difficulty. As a consequence, however, this means that no two neighbours
// may be eating simultaneously.

// variables
var philosophers = []string{"Plato", "Socrates", "Aristotle", "Pascal", "Locke"}
var wg sync.WaitGroup

func diningProblem(philosopher string, dominantHand, otherHand *sync.Mutex) {
	defer wg.Done()

	// print a message

	// lock both forks

	// print a message

	// unlock the mutexes

}

func main() {
	// print intro

	// add 5 (the number of philosophers) to the wait group
	wg.Add(len(philosophers))

	// we need to create a mutex for the very first fork (the one to
	// the left of the first philosopher). We create it as a pointer,
	// since a sync.Mutex must not be copied after its initial use.
	forkLeft := &sync.Mutex{}

	// spawn one goroutine for each philosopher
	for i := 0; i < len(philosophers); i++ {

		// create a mutex for the right fork
		forkRight := &sync.Mutex{}

		// call a goroutine with the current philsopher, and both mutexes
		go diningProblem(philosophers[i], forkLeft, forkRight)

		// create the next philosopher's left fork (which is the
		// current philosopher's right fork). Note that we are not
		// copying a mutex here; we are making forkLeft equal to the pointer
		// to an existing mutex, so it points to the same location in memory,
		// and does not copy it.
		forkLeft = forkRight
	}

	wg.Wait()
}