package main

const webPort = "80"

func main() {
	// connect to the database

	// create sessions

	// create channels

	// create waitgroup

	// set up the application config

	// set up mail

	// listen for web connections
}